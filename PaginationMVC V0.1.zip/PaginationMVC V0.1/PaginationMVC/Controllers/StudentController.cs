﻿using PaginationMVC.BusinessEntities.Models;
using PaginationMVC.BusinessRepository;
using PaginationMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PaginationMVC.Controllers
{
    public class StudentController : Controller
    {
        StudentRepository sdb = new StudentRepository();
        
        public ActionResult Index()
        {

            return View(sdb.GetStudent(0));
        }


        public ActionResult GetStudent(int currentPageIndex)
        {
            
            return PartialView("_StudentGrid", sdb.GetStudent(currentPageIndex));
        }

        
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(StudentModel studentModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    StudentRepository sdb = new StudentRepository();
                    if (sdb.AddStudent(studentModel))
                    {
                        ViewBag.Message = "Student Details Added successfully";
                        ModelState.Clear();
                    }
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Edit(int intId)
        {
            StudentRepository sdb = new StudentRepository();
            return View(sdb.GetStudents().Find(smodel => smodel.intId == intId));

        }

        [HttpPost]
        public ActionResult Edit(int intId, StudentModel studentModel)
        {
            try
            {
                StudentRepository sdb = new StudentRepository();
                sdb.UpdateStudent(studentModel);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Delete(int intId)
        {
            try
            {
                StudentRepository sdb = new StudentRepository();
                if (sdb.DeleteStudent(intId))
                {
                    ViewBag.Message = "Student deleted successfully";
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}