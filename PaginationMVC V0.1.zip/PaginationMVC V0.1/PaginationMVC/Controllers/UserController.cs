﻿using PaginationMVC.BusinessEntities.Models;
using PaginationMVC.BusinessRepository;
using PaginationMVC.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PaginationMVC.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(RegisterModel user)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    UserRepository rdb = new UserRepository();
                    if (rdb.AddUser(user))
                    {
                        ViewBag.Message = "User Details Added Successfully";
                        ModelState.Clear();
                    }
                }
                return View();
            }
            catch
            {
                return View();
            }
            
        }
    }
}

