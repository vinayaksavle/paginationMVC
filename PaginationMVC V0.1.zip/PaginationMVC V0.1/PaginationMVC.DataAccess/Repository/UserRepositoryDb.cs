﻿using PaginationMVC.BusinessEntities.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaginationMVC.DataAccess.Repository
{
    public class UserRepositoryDb
    {
        private static UserRepositoryDb _instance;
        private SqlConnection con;
        private void connection()
        {
            string constring = ConfigurationManager.ConnectionStrings["Constring"].ToString();
            con = new SqlConnection(constring);

        }

        public static UserRepositoryDb Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new UserRepositoryDb();
                }
                return _instance;
            }
        }

        public bool AddUser(RegisterModel user)
        {
            connection();
            SqlCommand cmd = new SqlCommand("sp_User_InsertUpdateDelete", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@strUsername", user.strUsername);
            cmd.Parameters.AddWithValue("@strEmail", user.strEmail);
            cmd.Parameters.AddWithValue("@strPassword", user.strPassword);
            cmd.Parameters.AddWithValue("@strCountry", user.strCountry);
            cmd.Parameters.AddWithValue("@strState", user.strState);
            cmd.Parameters.AddWithValue("@strCity", user.strCity);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }
    }
}
