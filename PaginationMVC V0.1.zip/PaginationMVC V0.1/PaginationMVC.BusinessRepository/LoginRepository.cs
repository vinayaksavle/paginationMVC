﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaginationMVC.BusinessRepository
{
    public class LoginRepository
    {
        private static LoginRepository _loginRepository;
        public static LoginRepository Instance
        {
            get
            {
                _loginRepository = new LoginRepository();
                return _loginRepository;
            }
        }

    }
}
