﻿using PaginationMVC.BusinessEntities.Models;
using PaginationMVC.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaginationMVC.BusinessRepository
{
    public class UserRepository
    {
        private static UserRepository _userRepository;
        public static UserRepository Instance
        {
            get
            {
                if (_userRepository == null)
                {
                    _userRepository = new UserRepository();
                }
                return _userRepository;
            }
        }

        public bool AddUser(RegisterModel user)
        {
            return UserRepositoryDb.Instance.AddUser(user);
        }
        
    }
}
