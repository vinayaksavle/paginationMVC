﻿using PaginationMVC.BusinessEntities.Models;
using PaginationMVC.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaginationMVC.BusinessRepository
{
    public class StudentRepository
    {
        private static StudentRepository _studentRepository;
        public static StudentRepository Instance
        {
            get
            {
                if (_studentRepository == null)
                {
                    _studentRepository = new StudentRepository();
                }
                return _studentRepository;
            }
        }

        public bool AddStudent(StudentModel studentModel)
        {
            return StudentRepositoryDb.Instance.AddStudent(studentModel);
        }

        public StudentModel GetStudent(int currentPage)
        {
            return StudentRepositoryDb.Instance.GetStudent(currentPage);
        }

        public List<StudentModel> GetStudents()
        {
            return StudentRepositoryDb.Instance.GetStudents();
        }

        public bool UpdateStudent(StudentModel studentModel)
        {
            return StudentRepositoryDb.Instance.UpdateStudent(studentModel);
        }

        public bool DeleteStudent(int intId)
        {
            return StudentRepositoryDb.Instance.DeleteStudent(intId);
        }


    }
}
