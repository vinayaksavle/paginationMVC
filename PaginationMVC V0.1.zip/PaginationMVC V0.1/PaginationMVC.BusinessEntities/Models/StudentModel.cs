﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PaginationMVC.BusinessEntities.Models
{
    public class StudentModel
    {
        [Display(Name = "Id")]
        public int intId { get; set; }

        [Required]
        [Display(Name = "Name")]
        public string strName { get; set; }

        [Required]
        [Display(Name = "City")]
        public string strCity { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [Display(Name = "Email")]
        public string strEmail { get; set; }

       
        //For pagination 
        public List<StudentModel> Students { get; set; }

        public int CurrentPageIndex { get; set; }

        public int PageCount { get; set; }

    }
}
