﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaginationMVC.BusinessEntities.Models
{
    public class RegisterModel
    {
        [Key]
        public int intUserId { get; set; }

        [Required]
        [StringLength(50)]
        [DisplayName("Country")]
        public string strCountry { get; set; }

        [Required]
        [StringLength(50)]
        [DisplayName("State")]
        public string strState { get; set; }

        [Required]
        [StringLength(50)]
        [DisplayName("City")]
        public string strCity { get; set; }

        [Required]
        [StringLength(50)]
        [DisplayName("Email")]
        public string strEmail { get; set; }

        [Required]
        [StringLength(50)]
        [DisplayName("Username")]
        public string strUsername { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 8, ErrorMessage = "Password must be 8 char long.")]
        [DisplayName("Password")]
        public string strPassword { get; set; }
    }
}
