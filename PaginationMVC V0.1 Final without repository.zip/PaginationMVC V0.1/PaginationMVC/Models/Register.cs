namespace PaginationMVC.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Register
    {
        [Key]
        public int intUserId { get; set; }

        [Required]
        [StringLength(50)]
        [DisplayName("Country")]
        public string strCountry { get; set; }

        [Required]
        [StringLength(50)]
        [DisplayName("State")]
        public string strState { get; set; }

        [Required]
        [StringLength(50)]
        [DisplayName("City")]
        public string strCity { get; set; }

        [Required]
        [StringLength(50)]
        [DisplayName("Email")]
        public string strEmail { get; set; }

        [Required]
        [StringLength(50)]
        [DisplayName("Username")]
        public string strUsername { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 8, ErrorMessage = "Password must be 8 char long.")]
        [DisplayName("Password")]
        public string strPassword { get; set; }
    }
}
