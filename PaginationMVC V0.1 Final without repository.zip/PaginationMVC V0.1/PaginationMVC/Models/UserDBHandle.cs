﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace PaginationMVC.Models
{
    public class UserDBHandle
    {
        private SqlConnection con;
        private void connection()
        {
            string constring = ConfigurationManager.ConnectionStrings["Constring"].ToString();
            con = new SqlConnection(constring);

        }

        public bool AddUser(Register user)
        {
            connection();
            SqlCommand cmd = new SqlCommand("sp_User_InsertUpdateDelete", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue("@strUsername", user.strUsername);
            cmd.Parameters.AddWithValue("@strEmail", user.strEmail);
            cmd.Parameters.AddWithValue("@strPassword", user.strPassword);
            cmd.Parameters.AddWithValue("@strCountry", user.strCountry);
            cmd.Parameters.AddWithValue("@strState", user.strState);
            cmd.Parameters.AddWithValue("@strCity", user.strCity);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }
    }
}