﻿using PaginationMVC.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PaginationMVC.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult UserLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UserLogin(Login login)
        {
            string constr = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                string query = "select strEmail, strPassword from tblUsers where strEmail=@strEmail and strPassword=@strPassword";
                
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    //cmd.Parameters.AddWithValue("@intUserId", user.intUserId);
                    cmd.Parameters.AddWithValue("@strEmail", login.strEmail);
                    cmd.Parameters.AddWithValue("@strPassword", login.strPassword);
                    SqlDataReader sdr = cmd.ExecuteReader();

                    if (sdr.Read())
                    {
                        Session["Email"] = login.strEmail.ToString();
                        Session["Password"] = login.strPassword.ToString();
                        return RedirectToAction("Index","Student");
                    }
                    else
                    {
                        ViewData["Message"] = "User Login Failed!";
                    }
                    con.Close();

                }

            }

            return View(login);
        }

        public ActionResult HomePage()
        {
            return View();
        }
    }
}