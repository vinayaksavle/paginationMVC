﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data;
using static PaginationMVC.Models.StudentModel;

namespace PaginationMVC.Models
{
    public class StudentDBHandle
    {
        private SqlConnection con;
        //public int PageSize { get; set; }
        //public int PageCount { get; set; }
        //public int CurrentPageIndex { get; set; }
        private void Connection()
        {
            string constring = ConfigurationManager.ConnectionStrings["Constring"].ToString();
            con = new SqlConnection(constring);
        }

        public bool AddStudent(StudentModel studentModel)
        {
            Connection();
            SqlCommand cmd = new SqlCommand("spInsertStudent",con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@strName", studentModel.strName);
            cmd.Parameters.AddWithValue("@strCity", studentModel.strCity);
            cmd.Parameters.AddWithValue("@strEmail", studentModel.strEmail);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public StudentModel GetStudent(int currentPage)
        {
            Connection();
            
            List<StudentModel> studentList = new List<StudentModel>();
            SqlCommand cmd = new SqlCommand("spGetStudent", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            con.Open();
            sd.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                studentList.Add(
                    new StudentModel
                    {
                        intId = Convert.ToInt32(dr["intId"]),
                        strName = Convert.ToString(dr["strName"]),
                        strCity = Convert.ToString(dr["strCity"]),
                        strEmail = Convert.ToString(dr["strEmail"])
                    });
            }
            int maxRows = 5;
            StudentModel std = new StudentModel();
            std.Students = studentList.OrderBy(s=>s.intId).Skip((currentPage-1)*maxRows).Take(maxRows).ToList();
            double pageCount = (double)((decimal)studentList.Count() / Convert.ToDecimal(maxRows));
            std.PageCount = (int)Math.Ceiling(pageCount);
            std.CurrentPageIndex = currentPage;

            return std;
        }

        public List<StudentModel> GetStudents()
        {
            Connection();
            List<StudentModel> studentList = new List<StudentModel>();
            SqlCommand cmd = new SqlCommand("spGetStudent", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            con.Open();
            sd.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                studentList.Add(
                    new StudentModel
                    {
                        intId = Convert.ToInt32(dr["intId"]),
                        strName = Convert.ToString(dr["strName"]),
                        strCity = Convert.ToString(dr["strCity"]),
                        strEmail = Convert.ToString(dr["strEmail"])
                    });
            }

            return studentList;
        }

        public bool UpdateStudent(StudentModel studentModel)
        {
            Connection();
            SqlCommand cmd = new SqlCommand("spUpdateStudent", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@intId", studentModel.intId);
            cmd.Parameters.AddWithValue("@strName", studentModel.strName);
            cmd.Parameters.AddWithValue("@strCity", studentModel.strCity);
            cmd.Parameters.AddWithValue("@strEmail", studentModel.strEmail);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteStudent(int intId)
        {
            Connection();
            SqlCommand cmd = new SqlCommand("spDeleteStudent", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@intId", intId);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            if (i >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}