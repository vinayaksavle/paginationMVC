﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PaginationMVC.Models
{
    public class Login
    {
        [Required]
        [StringLength(50)]
        [DisplayName("Email")]
        public string strEmail { get; set; }

        [Required]
        [StringLength(50)]
        [DisplayName("Password")]
        public string strPassword { get; set; }
    }
}