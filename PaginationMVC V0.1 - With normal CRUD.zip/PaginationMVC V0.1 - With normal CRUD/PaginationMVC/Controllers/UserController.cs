﻿using PaginationMVC.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PaginationMVC.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(Register user)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    UserDBHandle rdb = new UserDBHandle();
                    if (rdb.AddUser(user))
                    {
                        ViewBag.Message = "User Details Added Successfully";
                        ModelState.Clear();
                    }
                }
                return View();
            }
            catch
            {
                return View();
            }



            //string constr = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
            //using(SqlConnection con=new SqlConnection(constr))
            //{
            //    string query = "INSERT INTO tblUsers (strUsername,strEmail,strPassword,strCountry,strState,strCity) VALUES (@strUsername,@strEmail,@strPassword,@strCountry,@strState,@strCity)";
            //    query += "SELECT SCOPE_IDENTITY()";
            //    using (SqlCommand cmd = new SqlCommand(query))
            //    {
            //        cmd.Connection = con;
            //        con.Open();
            //        //cmd.Parameters.AddWithValue("@intUserId", user.intUserId);
            //        cmd.Parameters.AddWithValue("@strUsername", user.strUsername);
            //        cmd.Parameters.AddWithValue("@strEmail", user.strEmail);
            //        cmd.Parameters.AddWithValue("@strPassword", user.strPassword);
            //        cmd.Parameters.AddWithValue("@strCountry", user.strCountry);
            //        cmd.Parameters.AddWithValue("@strState", user.strState);
            //        cmd.Parameters.AddWithValue("@strCity", user.strCity);
            //        user.intUserId = Convert.ToInt32(cmd.ExecuteScalar());
            //        con.Close();

            //    }

            //}

        }
    }
}

